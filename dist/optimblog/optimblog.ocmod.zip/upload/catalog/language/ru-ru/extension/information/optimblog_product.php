<?php
/**
 * @package    OptimBlog
 * @version    3.0.1.0
 * @author     Dmitriy Khokhlov <admin@optimlab.com>
 * @copyright  Copyright (c) 2018, Dmitriy Khokhlov. (http://optimlab.com/)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       http://optimlab.com
 */
// Text
$_['text_related_information'] = 'Рекомендуемые статьи';
$_['text_related_reviews']     = '%s отзывов';
$_['text_read']                = 'Подробнее..';
