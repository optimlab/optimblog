<?php
/**
 * @package    OptimBlog
 * @version    3.0.0.9
 * @author     Dmitriy Khokhlov <admin@optimlab.com>
 * @copyright  Copyright (c) 2018, Dmitriy Khokhlov. (http://optimlab.com/)
 * @license    https://opensource.org/licenses/GPL-3.0
 * @link       http://optimlab.com
 */
// Heading
$_['heading_title']    = 'Articles';

// Text
$_['text_success']     = 'Success: You have modified OptimBlog!';
$_['text_list']        = 'OptimBlog List';

// Column
$_['column_name']      = 'Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify OptimBlog!';
